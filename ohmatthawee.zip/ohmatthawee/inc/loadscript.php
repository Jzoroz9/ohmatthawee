<!-- Core -->
<script src="assets/js/libs/jquery-3.7.0.min.js"></script>
<script src="assets/js/libs/jquery.easing.min.js"></script>
<script src="assets/js/libs/modernizr.min.js"></script>
<script src="assets/js/libs/aos.js"></script>
<script src="assets/js/libs/lazyload.min.js"></script>

<script src="assets/js/libs/swiper-bundle.min.js"></script>

<!-- Custom -->
<script src="assets/js/main.js<?=$modify?>"></script>
<script src="assets/js/accessibility.js<?=$modify?>"></script>
<script>var raf = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;</script>